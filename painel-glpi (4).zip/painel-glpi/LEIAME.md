# Painel de Atendimento GLPI

Painel web com gráficos configuráveis (pizza, rosca, polar, barras, barras empilhadas,
linhas, áreas, radar, cartões e tabelas) sobre os chamados dos técnicos do GLPI.
Os dados vêm da **API REST do GLPI**, configurada pela própria tela do painel.

## 1. Instalar o Docker (Rocky / Alma / RHEL)

```bash
dnf -y install dnf-plugins-core
dnf config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
dnf -y install docker-ce docker-ce-cli containerd.io docker-compose-plugin
systemctl enable --now docker
```

## 2. Subir o painel

Copie a pasta `painel-glpi` para o servidor (ex.: `/opt/painel-glpi`) e rode:

```bash
cd /opt/painel-glpi
nano docker-compose.yml        # troque PANEL_PASSWORD e confira PAINEL_HOSTS
docker compose up -d --build
firewall-cmd --permanent --add-port=8080/tcp && firewall-cmd --reload   # já liberada se o painel rodava antes
```

Acesse `https://helpdesk.grupovia.lan:8080` (ou `https://IP_DO_SERVIDOR:8080`) e entre com o usuário e a senha definidos no
`docker-compose.yml` (padrão: `admin` / `TroqueEstaSenha`). Esse administrador é criado
só na primeira execução; depois disso, os usuários são gerenciados pela tela do painel.

O painel usa **HTTPS na mesma porta 8080**. Quem acessar `http://...:8080` (favoritos antigos ou
o endereço digitado sem `https://`) é redirecionado sozinho para `https://...:8080`.

### Certificado (sem o aviso "Sua conexão não é particular")

Um certificado vale para um **nome** (ou IP), não para uma porta: o mesmo certificado serve o
GLPI (443), o portal de consulta (8443) e este painel (8080). O aviso
**NET::ERR_CERT_AUTHORITY_INVALID** aparece quando o navegador não confia em **quem emitiu** o
certificado. Veja a seção 10 para emitir um certificado por uma CA interna e distribuí-la.

* **Automático:** na primeira execução, sem certificado em `data/certs/`, o painel cria uma CA
  interna (`data/certs/ca.crt`) e emite com ela um certificado para `PAINEL_HOSTS`.
* **Recomendado:** `sudo ./criar-certificado-interno.sh` (seção 10). Se o portal de consulta já
  gerou o certificado curinga, o painel passa a usar **o mesmo**, da mesma CA.

O log da subida (`docker compose logs | head -20`) mostra o certificado em uso, os nomes que ele
cobre e avisa se faltar algum endereço de `PAINEL_HOSTS`, se for autoassinado ou se estiver perto
de vencer.

## 3. Configurar a API (primeiro acesso)

A tela de configurações abre sozinha. Preencha:

| Campo | Onde encontrar no GLPI |
|---|---|
| URL da API | `https://IP_DO_GLPI/apirest.php` |
| App Token | Configurar > Geral > API > (cliente da API) |
| User Token | Minhas configurações > Chaves de acesso remoto > Token da API |
| Perfil dos técnicos | Nome exato do perfil, ex.: `Technician` |

Clique em **Testar conexão** e depois em **Salvar configurações**.

Na mesma tela:

* **Tempo limite da API** (padrão 90 s) e **Tentativas** (padrão 3): se o GLPI estiver lento,
  aumente o tempo limite (ex.: 120 a 180 s). Entre as tentativas o painel espera 5 s, 10 s...
* **Atualizar dados a cada (min)**: com o GLPI sobrecarregado, use 30 minutos para reduzir a carga.

Se o GLPI não responder, o painel **continua mostrando os últimos dados** com um aviso amarelo
e tenta de novo depois de alguns minutos.
**Verificar certificado SSL:** com o GLPI usando o certificado da CA interna (seção 10), deixe
marcado: o painel confia na CA de `data/certs/ca.crt` (e em `data/certs/ca-glpi.crt`, se o GLPI
usar outra CA) além das autoridades públicas. Desmarque só se o certificado do GLPI estiver vencido.

O cliente da API no GLPI precisa estar **ativo** e liberar o **IP do servidor do painel**.
O User Token deve ser de um usuário que enxergue **todas as entidades** e tenha leitura de
chamados, usuários e perfis (um Super-Admin dedicado à integração é o mais simples).

## 4. Personalizar os gráficos

* **Editar painel** > **Adicionar gráfico**: escolha a métrica, o tipo de gráfico, as cores,
  a largura e a altura.
* Em cada gráfico: ✎ edita, ← → muda a posição, ✕ remove.
* A paleta **Por significado (status/SLA)** usa verde para no prazo e vermelho para expirado.
* O filtro de **período** e de **técnicos** no topo vale para todos os gráficos.
* O layout fica salvo no servidor (pasta `data/`), igual para todos que acessarem.

### Por que um chamado está "Sem SLA"

Passe o mouse na fatia **Sem SLA** do gráfico "Situação do SLA" (no painel e na página por
técnico). O balão separa os chamados pelo motivo provável, com as categorias que mais aparecem:

| Motivo | O que significa | O que fazer no GLPI |
|---|---|---|
| Categoria sem SLA configurado | Nenhum chamado dessa categoria recebeu SLA | Criar/ajustar a regra de SLA para a categoria |
| Categoria com SLA, mas não aplicado | Outros chamados da categoria têm SLA, este não | Chamado aberto antes da regra, categoria trocada depois ou SLA removido à mão |
| Sem categoria | Chamado sem categoria | Exigir categoria na abertura; as regras de SLA costumam usá-la |
| SLA atribuído sem prazo calculado | O chamado tem SLA, mas sem data limite | Conferir o calendário e o tempo do SLA |

O motivo de cada chamado também sai no **CSV dos chamados**, na coluna "Motivo sem SLA".

## 5. Usuários do painel

Menu com o seu nome (canto superior direito):

* **Usuários do painel** (administradores): cadastrar, editar, trocar senha e remover usuários.
  * **Administrador**: edita o painel, as configurações da API e os usuários.
  * **Somente visualização**: consulta, filtra e exporta, sem alterar nada.
* **Alterar minha senha**: disponível para todos.
* **Sair**: encerra a sessão.

As senhas são gravadas com hash (PBKDF2) em `data/users.json`. Se perder o acesso de todos
os administradores, apague `data/users.json` e reinicie o contêiner: o administrador do
`docker-compose.yml` é recriado.

## 6. Exportar PDF e CSV

* **Exportar > PDF do painel**: todos os gráficos, com período, técnicos filtrados e data
  de geração. Tabelas saem completas, em quantas páginas forem necessárias.
* **Exportar > CSV dos chamados**: um chamado por linha (abertos no período, técnicos
  filtrados), com status, técnico, datas, prazo e situação do SLA, motivo de estar sem SLA,
  categoria, reabertura e tempo de solução.
* Botão **⤓** em cada gráfico: baixa só aquele gráfico em CSV ou PDF.

Os CSV usam ponto e vírgula e acentuação compatível com o Excel em português.

## 7. Pendências

Bloco de gráficos sobre os chamados que estão **Pendentes agora** (não depende do período):

* **Tempo médio**, **maior tempo** e **soma do tempo** em pendência, e quantos estão
  pendentes **há mais de 7 dias**.
* **Pendentes por tempo parado**: até 1 dia, 1 a 3, 3 a 7, 7 a 15, 15 a 30 e mais de 30 dias.
* **Soma e média do tempo em pendência por técnico**, em gráfico e na tabela
  "Pendências por técnico".
* **Chamados pendentes**: lista do parado há mais tempo ao mais recente, com o tempo
  pendente atual e o total já acumulado (somando pendências anteriores do mesmo chamado).

O tempo é contado em horas corridas a partir de quando o chamado entrou em Pendente
(campo "Data de início da espera" do GLPI). Painéis já personalizados recebem esse bloco
automaticamente no fim, uma única vez; depois você pode mover ou remover os gráficos.

## 8. Desempenho por técnico (apresentação)

Botão **Por técnico**, no topo do painel (abre em uma nova aba, endereço `/tecnico`).

* Escolha o **técnico** e o **período**. A página mostra somente os dados dele: indicadores
  comparados com a média da equipe (verde = melhor que a média, vermelho = pior), status,
  situação do SLA, evolução diária e as listas de chamados em aberto e com SLA expirado.
* **Setas ‹ ›** (ou as setas do teclado) passam para o técnico anterior ou o próximo, em
  ordem alfabética. Depois do último, volta ao primeiro.
* **▶ Apresentação** troca de técnico sozinho no intervalo escolhido (barra de espaço
  pausa ou continua). **Tela cheia** (tecla F) é ideal para TV.
* **Ranking**: o cartão do técnico mostra a posição dele no ranking (ex.: "🥇 1º de 8 · 92,5 pts");
  clicar abre o ranking completo.
* **Foto**: administradores usam "Adicionar foto" no cartão do técnico. A imagem é
  recortada em quadrado e reduzida automaticamente, e fica salva em `data/fotos/`.
* **Baixar PDF** gera o relatório do técnico exibido.
* Os cartões **Soma do tempo em pendência** e **Maior tempo em pendência** mostram os
  chamados pendentes dele agora; a lista "Chamados em aberto" traz a coluna "Pendente há".

Aparecem apenas os técnicos ativos no GLPI.

## 8.1 Backlog (fila de chamados em aberto)

Grupo **Backlog** no painel (painéis já personalizados recebem estes gráficos no fim, uma única vez):

| Gráfico | O que mostra |
|---|---|
| Idade média do backlog | Há quantos dias, em média, os chamados em aberto foram abertos |
| Chamado mais antigo em aberto | Idade do chamado em aberto há mais tempo |
| Envelhecimento do backlog | Em aberto agora, por idade: até 1 dia, 1–3, 3–7, 7–15, 15–30, mais de 30 dias |
| Evolução do backlog | Quantos estavam em aberto no fim de cada dia (ou mês) do período, e quantos com SLA vencido |
| Backlog por categoria | Onde a fila acumula (12 categorias com mais chamados) |
| Chamados em aberto mais antigos | Lista do mais antigo ao mais recente |

Idades em **dias corridos** (não descontam fim de semana nem pendência). Na evolução, cada chamado conta
desde a abertura até a solução; um chamado reaberto aparece pela situação atual (o GLPI não guarda as datas de
cada reabertura). Como nos demais gráficos, entram os chamados dos técnicos selecionados.

## 9. Ranking de técnicos

Botão **Ranking** no topo do painel (abre em nova aba, endereço `/ranking`), com pódio dos três
primeiros e a classificação completa. Atualiza sozinho a cada 5 minutos e tem **Tela cheia**
(tecla F), para TV. No painel há também três gráficos novos no grupo **Ranking**: a tabela
"Ranking de técnicos", "Pontuação do ranking" e "Composição da pontuação" (painéis já
personalizados recebem esses gráficos no fim, uma única vez).

**Quais chamados contam:** os **atendidos no período** de cada técnico, ou seja, solucionados no
período ou com a solução recusada (reabertos) no período. Entram só técnicos ativos com pelo menos
**5 atendidos** (configurável); os demais aparecem em "Fora do ranking".

**Pontuação de 0 a 100**, média ponderada de quatro notas:

| Critério | Peso padrão | Nota (0 a 100) |
|---|---|---|
| SLA cumprido | 40 | % dos solucionados (com prazo) resolvidos dentro do prazo |
| Menos reabertos | 20 | 100 − taxa de reabertura × 100 ÷ 20% (20% ou mais de reabertura = 0) |
| Menos tempo em pendência | 20 | 100 − horas médias em pendência por chamado × 100 ÷ 72 h (72 h ou mais = 0) |
| Solução mais rápida | 20 | 100 − tempo médio de solução × 100 ÷ 48 h (48 h ou mais = 0) |

* Tempo em pendência = tempo acumulado em Pendente (`waiting_duration` do GLPI) + o período de
  pendência atual, se o chamado ainda estiver Pendente.
* Tempo de solução = o mesmo do indicador "Tempo médio de solução": o tempo que o GLPI calcula
  para cada chamado solucionado no período, pelo calendário (horas úteis, se houver calendário)
  e **sem o tempo em pendência**, que já tem critério próprio.
* Critério sem dados no período (ex.: nenhum chamado com SLA): fica de fora e a pontuação usa só
  os outros.
* Empate: vence quem tem mais SLA, depois menos reabertos, menos pendência, solução mais rápida e
  mais atendidos.
  Pontuações e critérios iguais dividem a posição.
* **Configurações > Ranking de técnicos** (administradores): pesos, limites que zeram as notas
  e mínimo de atendidos. Ex.: para priorizar SLA, use pesos 55 / 15 / 15 / 15. Se as configurações
  já tinham sido salvas antes, os pesos antigos (50 / 25 / 25) continuam e o tempo de solução entra
  com peso 20; ajuste à vontade.

A data da reabertura vem da recusa da solução no GLPI (`ITILSolution`, data de aprovação/recusa).

### Reabertura indevida (cliente recusou a solução por engano)

O GLPI não permite "desfazer" uma recusa de solução, e ela contaria contra o técnico no ranking. Para anular:

1. No chamado, adicione um **acompanhamento** (pode ser **privado**) com o texto **`#reabertura-indevida`**
   e a justificativa. Ex.: `#reabertura-indevida cliente confirmou por telefone que clicou em recusar sem querer.`
2. No painel, clique em **Atualizar dados**.

A reabertura deixa de contar no ranking, no indicador "Reabertos" e nos gráficos; no CSV dos chamados a coluna
"Reaberto" mostra **Desconsiderada**. Regras de segurança:

- o **técnico atribuído ao chamado não anula a própria reabertura** (o acompanhamento dele é ignorado);
- em **Configurações > Ranking de técnicos > Quem pode desconsiderar**, informe logins (ex.: `supervisor,coordenador`)
  para que só eles possam anular;
- o marcador só anula recusas **anteriores** a ele: se o cliente recusar de novo depois, a nova reabertura conta;
- o texto do marcador pode ser trocado em Configurações (deixe vazio para desligar o recurso).

### Fórmula do ranking

Na página **Ranking**, clique em **"Como a pontuação é calculada"**: aparecem a fórmula, o peso de cada
critério (e quanto ele vale em %), como cada nota é calculada com os limites atuais e uma conta de exemplo com
o 1º colocado. Em Configurações, **peso vazio ou 0 tira o critério do cálculo**.

## 10. Certificado: um só para GLPI, portal e painel

### 10.1 Emitir ou reaproveitar o certificado curinga

```bash
cd /opt/painel-glpi
sudo ./criar-certificado-interno.sh
```

O script usa a CA de `/etc/pki/grupovia-ca/` (cria na primeira vez, ou adota a que o painel tinha
criado em `data/certs`). Se o certificado `*.grupovia.lan` já existir (criado pelo **portal de
consulta**), ainda valer por mais de 30 dias e cobrir os nomes/IPs, ele é **reaproveitado**: GLPI,
portal e painel ficam com o mesmo certificado. Caso contrário, emite um novo
(`/etc/pki/tls/certs/grupovia-curinga.crt` e `/etc/pki/tls/private/grupovia-curinga.key`).
Depois copia para `data/certs` e reinicia o painel.

* Outros IPs/nomes: `sudo IPS="10.1.100.128 10.1.100.200" NOMES="srv-glpi" ./criar-certificado-interno.sh`
* Forçar um certificado novo: `sudo RENOVAR=1 ./criar-certificado-interno.sh`. A CA continua a
  mesma (nada a redistribuir), mas recarregue o Apache e rode `./usar-certificado-glpi.sh` também
  na pasta do portal, para todos usarem o certificado novo.

Guarde uma cópia de `/etc/pki/grupovia-ca/ca.key` em local seguro: quem tem essa chave consegue
emitir certificados aceitos pelas máquinas da empresa.

### 10.2 Fazer as máquinas confiarem na CA (uma vez)

GPO: Configuração do Computador > Políticas > Configurações do Windows > Configurações de
Segurança > Políticas de Chave Pública > **Autoridades de Certificação Raiz Confiáveis** >
Importar `/etc/pki/grupovia-ca/ca.crt`. Se já foi feito para o portal, não precisa repetir.
No Firefox, ative `security.enterprise_roots.enabled`.

### 10.3 GLPI (Apache)

```apache
SSLCertificateFile    /etc/pki/tls/certs/grupovia-curinga.crt
SSLCertificateKeyFile /etc/pki/tls/private/grupovia-curinga.key
```

`systemctl reload httpd`.

### 10.4 Usar um certificado existente (AD CS, por exemplo)

```bash
CERT=/caminho/cert.crt CHAVE=/caminho/chave.key CADEIA=/caminho/cadeia.crt ./usar-certificado-glpi.sh
```

Confere se a chave combina, se `helpdesk.grupovia.lan` está no certificado (curinga aceito), se
não está vencido, avisa se for autoassinado e reinicia o painel. Se algo estiver errado, nada é
alterado.

## 11. Comandos úteis

```bash
docker compose logs -f          # ver o que está acontecendo
docker compose restart          # reiniciar
docker compose up -d --build    # aplicar atualizações do painel
```

Os dados do GLPI ficam em cache pelo tempo definido em "Atualizar dados a cada (min)".
O botão **Atualizar dados** força uma nova leitura na hora.
