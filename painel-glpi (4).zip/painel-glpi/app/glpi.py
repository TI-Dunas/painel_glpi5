"""Cliente da API REST do GLPI e carga dos dados usados no painel."""
import html
import os
import tempfile
import threading
import time
from datetime import datetime

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# CA interna (data/certs/ca.crt) ou da empresa (data/certs/ca-glpi.crt): com "Verificar certificado
# SSL" marcado, o painel confia nelas ALEM das autoridades publicas, entao da para verificar o
# certificado do GLPI sem desligar a checagem.
_PASTA_CERT = os.path.join(os.environ.get("DATA_DIR", "/data"), "certs")
_CAS_EXTRAS = ("ca-glpi.crt", "ca.crt")
_pacote = {"chave": None, "caminho": None}
_trava_pacote = threading.Lock()


def verificacao_ssl(cfg):
    """Valor para o parametro verify do requests."""
    if not cfg.get("verify_ssl"):
        return False
    extras = [os.path.join(_PASTA_CERT, n) for n in _CAS_EXTRAS if os.path.isfile(os.path.join(_PASTA_CERT, n))]
    if not extras:
        return True
    chave = tuple((p, os.path.getmtime(p)) for p in extras)
    with _trava_pacote:
        if _pacote["chave"] != chave:
            try:
                import certifi
                partes = [open(certifi.where(), "rb").read()] + [open(p, "rb").read() for p in extras]
                destino = os.path.join(tempfile.gettempdir(), f"painel-confiaveis-{os.getpid()}.pem")
                with open(destino + ".novo", "wb") as f:
                    f.write(b"\n".join(partes))
                os.replace(destino + ".novo", destino)
                _pacote.update(chave=chave, caminho=destino)
            except OSError:
                return True
        return _pacote["caminho"]


class GlpiError(Exception):
    pass


def parse_dt(valor):
    if not valor:
        return None
    try:
        return datetime.strptime(str(valor)[:19], "%Y-%m-%d %H:%M:%S")
    except ValueError:
        return None


def normalizar_url(url):
    url = (url or "").strip().rstrip("/")
    if url and "apirest.php" not in url:
        url += "/apirest.php"
    return url


class GlpiClient:
    def __init__(self, cfg):
        self.url = normalizar_url(cfg.get("glpi_url"))
        self.app_token = (cfg.get("app_token") or "").strip()
        self.user_token = (cfg.get("user_token") or "").strip()
        self.verify = verificacao_ssl(cfg)
        self.timeout = max(10, int(cfg.get("timeout") or 90))
        self.tentativas = max(1, int(cfg.get("retries") or 3))
        self.headers = None
        if not self.url:
            raise GlpiError("URL da API do GLPI nao configurada.")
        if not self.user_token:
            raise GlpiError("User Token nao configurado.")

    def _base(self):
        h = {"Content-Type": "application/json"}
        if self.app_token:
            h["App-Token"] = self.app_token
        return h

    def _requisicao(self, metodo, url, timeout, **kwargs):
        """Repete a chamada quando o GLPI demora ou a conexao cai (espera 5 s, 10 s, ...)."""
        for tentativa in range(1, self.tentativas + 1):
            try:
                return requests.request(metodo, url, verify=self.verify, timeout=timeout, **kwargs)
            except requests.exceptions.SSLError:
                raise GlpiError("Erro de certificado SSL ao acessar o GLPI. Coloque a CA que emitiu o "
                                "certificado do GLPI em data/certs/ca-glpi.crt ou desmarque "
                                "'Verificar certificado SSL' nas configuracoes.")
            except (requests.exceptions.Timeout, requests.exceptions.ConnectionError) as e:
                if tentativa == self.tentativas:
                    raise GlpiError(f"O GLPI não respondeu em {self.url} após {self.tentativas} "
                                    f"tentativa(s) de até {timeout} s cada.")
                time.sleep(5 * tentativa)
            except requests.exceptions.RequestException as e:
                raise GlpiError(f"Nao foi possivel conectar em {self.url}: {e}")

    def __enter__(self):
        h = self._base()
        h["Authorization"] = f"user_token {self.user_token}"
        r = self._requisicao("GET", f"{self.url}/initSession", self.timeout, headers=h)
        if r.status_code != 200:
            raise GlpiError(f"Login na API recusado (HTTP {r.status_code}): {r.text[:300]}")
        self.headers = self._base()
        self.headers["Session-Token"] = r.json()["session_token"]
        try:  # garante visao de todas as entidades
            requests.post(f"{self.url}/changeActiveEntities", headers=self.headers,
                          json={"entities_id": 0, "is_recursive": True},
                          verify=self.verify, timeout=self.timeout)
        except requests.exceptions.RequestException:
            pass
        return self

    def __exit__(self, *args):
        try:
            requests.get(f"{self.url}/killSession", headers=self.headers,
                         verify=self.verify, timeout=10)
        except requests.exceptions.RequestException:
            pass

    def get(self, path, params=None):
        # leituras de listas grandes podem levar mais que o login
        return self._requisicao("GET", f"{self.url}/{path}", max(180, self.timeout * 2),
                                headers=self.headers, params=params)

    def get_all(self, itemtype, passo=1000, opcional=False, filtros=None):
        itens, inicio = [], 0
        while True:
            r = self.get(itemtype, {**(filtros or {}), "range": f"{inicio}-{inicio + passo - 1}"})
            if r.status_code == 400 and "ERROR_RANGE_EXCEED_TOTAL" in r.text:
                break
            if r.status_code not in (200, 206):
                if opcional:
                    return []
                raise GlpiError(f"Erro ao ler {itemtype} (HTTP {r.status_code}): {r.text[:300]}")
            lote = r.json()
            if not isinstance(lote, list) or not lote:
                break
            itens.extend(lote)
            inicio += len(lote)
            total = None
            faixa = r.headers.get("Content-Range", "")
            if "/" in faixa:
                try:
                    total = int(faixa.split("/")[-1])
                except ValueError:
                    pass
            if total is not None and inicio >= total:
                break
            if total is None and len(lote) < passo:
                break
        return itens


def desconsiderar_reaberturas(g, cfg, chamados):
    """Reabertura indevida (ex.: o cliente recusou a solucao por engano): um acompanhamento com o marcador
    (padrao "#reabertura-indevida") anula as recusas ANTERIORES a ele, para nao prejudicar o tecnico.
    Para valer, o acompanhamento precisa ser de alguem que NAO seja tecnico atribuido ao chamado
    (o tecnico nao anula a propria reabertura) e, se houver lista de autorizados, de um deles."""
    marcador = (cfg.get("reab_marcador") or "").strip()
    if not marcador:
        return
    alvo = {t["id"]: t for t in chamados.values() if t["refused"]}
    if not alvo:
        return
    autorizados = {a.strip().lower() for a in (cfg.get("reab_autorizados") or "").split(",") if a.strip()}
    logins = {}

    def login(uid):
        if uid not in logins:
            r = g.get(f"User/{uid}")
            u = r.json() if r.status_code == 200 else {}
            logins[uid] = ((u.get("name") or "").lower(), nome_usuario(u, uid) if u else f"Usuário {uid}")
        return logins[uid]

    for f in g.get_all("ITILFollowup", opcional=True, filtros={"searchText[content]": marcador}):
        if f.get("itemtype") != "Ticket" or f.get("items_id") not in alvo:
            continue
        if marcador.lower() not in html.unescape(str(f.get("content") or "")).lower():
            continue
        t = alvo[f["items_id"]]
        uid = _id(f.get("users_id"))
        if not uid or uid in t["techs"]:
            continue                                  # tecnico do chamado nao anula a propria reabertura
        usuario, nome = login(uid)
        if autorizados and usuario not in autorizados:
            continue
        quando = parse_dt(f.get("date")) or parse_dt(f.get("date_creation"))
        if t["refused_date"] and quando and quando < t["refused_date"]:
            continue                                  # marcador antigo: reabertura nova continua valendo
        t["refused"] = False
        t["reab_desconsiderada"] = {"por": nome, "em": quando}


def _id(valor):
    try:
        return int(valor or 0)
    except (TypeError, ValueError):
        return 0


def nome_usuario(u, uid):
    nome = " ".join(x for x in [u.get("firstname"), u.get("realname")] if x)
    return nome or u.get("name") or f"Usuario {uid}"


def buscar_perfis_tecnico(g, nome_perfil):
    perfis = g.get_all("Profile")
    alvo = (nome_perfil or "Technician").strip().lower()
    ids = {p["id"] for p in perfis if str(p.get("name", "")).strip().lower() == alvo}
    if not ids:
        nomes = ", ".join(sorted(str(p.get("name")) for p in perfis))
        raise GlpiError(f"Perfil '{nome_perfil}' nao encontrado. Perfis existentes: {nomes}")
    return ids


def testar(cfg):
    with GlpiClient(cfg) as g:
        perfis = buscar_perfis_tecnico(g, cfg.get("tech_profile"))
        usuarios = {pu["users_id"] for pu in g.get_all("Profile_User")
                    if pu.get("profiles_id") in perfis}
    return (f"Conexao OK. Perfil '{cfg.get('tech_profile')}' encontrado com "
            f"{len(usuarios)} usuario(s).")


def carregar(cfg):
    with GlpiClient(cfg) as g:
        perfis = buscar_perfis_tecnico(g, cfg.get("tech_profile"))
        ids_tec = {pu["users_id"] for pu in g.get_all("Profile_User")
                   if pu.get("profiles_id") in perfis}

        tecnicos = {}
        for uid in ids_tec:
            r = g.get(f"User/{uid}")
            if r.status_code != 200:
                continue
            u = r.json()
            if u.get("is_deleted"):
                continue
            tecnicos[uid] = {"id": uid, "name": nome_usuario(u, uid),
                             "active": bool(u.get("is_active", 1))}

        categorias = {}
        for c in g.get_all("ITILCategory", opcional=True):
            categorias[c["id"]] = c.get("completename") or c.get("name") or f"Categoria {c['id']}"

        chamados = {}
        for t in g.get_all("Ticket"):
            chamados[t["id"]] = {
                "id": t["id"],
                "name": t.get("name") or "",
                "status": int(t.get("status") or 0),
                "date": parse_dt(t.get("date")),
                "solvedate": parse_dt(t.get("solvedate")),
                "closedate": parse_dt(t.get("closedate")),
                "ttr": parse_dt(t.get("time_to_resolve")),
                "solve_delay": int(t.get("solve_delay_stat") or 0),
                "begin_waiting": parse_dt(t.get("begin_waiting_date")),
                "waiting_duration": int(t.get("waiting_duration") or 0),
                "categoria": _id(t.get("itilcategories_id")),
                "sla_ttr": _id(t.get("slas_id_ttr")),      # SLA de solucao atribuido (0 = nenhum)
                "techs": set(),
                "refused": False,
                "priority": int(t.get("priority") or 3),   # 1 muito baixa ... 6 maior (critica)
                "refused_date": None,   # quando a solucao foi recusada pela ultima vez (reabertura)
                "reab_desconsiderada": None,   # {"por": nome, "em": data} quando a reabertura foi anulada
                "waiting_validation": False,
            }

        for tu in g.get_all("Ticket_User"):
            if (tu.get("type") == 2 and tu.get("users_id") in tecnicos
                    and tu.get("tickets_id") in chamados):
                chamados[tu["tickets_id"]]["techs"].add(tu["users_id"])

        for s in g.get_all("ITILSolution", opcional=True):
            if s.get("itemtype") == "Ticket" and s.get("status") == 4 and s.get("items_id") in chamados:
                c = chamados[s["items_id"]]
                c["refused"] = True
                quando = (parse_dt(s.get("date_approval")) or parse_dt(s.get("date_mod"))
                          or parse_dt(s.get("date_creation")))
                if quando and (c["refused_date"] is None or quando > c["refused_date"]):
                    c["refused_date"] = quando

        desconsiderar_reaberturas(g, cfg, chamados)

        for v in g.get_all("TicketValidation", opcional=True):
            if v.get("status") == 2 and v.get("tickets_id") in chamados:
                chamados[v["tickets_id"]]["waiting_validation"] = True

    return {
        "techs": tecnicos,
        "tickets": [t for t in chamados.values() if t["techs"]],
        "categorias": categorias,
        "unassigned_new": sum(1 for t in chamados.values() if not t["techs"] and t["status"] == 1),
    }
