/* Painel GLPI - pagina "Ranking de tecnicos" */
(function () {
  "use strict";

  const $ = (s, el = document) => el.querySelector(s);
  const el = (tag, cls, texto) => { const e = document.createElement(tag); if (cls) e.className = cls; if (texto !== undefined) e.textContent = texto; return e; };
  const fmtNum = (v) => (typeof v === "number" ? v.toLocaleString("pt-BR", { maximumFractionDigits: 1 }) : v);
  const iso = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  const salvarLocal = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* ignora */ } };
  const lerLocal = (k, p) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : p; } catch (e) { return p; } };
  const MEDALHA = { 1: "🥇", 2: "🥈", 3: "🥉" };
  const ATUALIZAR_MS = 5 * 60 * 1000;   // TV: recarrega sozinho a cada 5 minutos
  let timer = null;

  async function api(url) {
    const r = await fetch(url);
    if (r.status === 401) { window.location.href = "/login"; throw new Error("Sessão expirada."); }
    let j = null;
    try { j = await r.json(); } catch (e) { /* sem corpo */ }
    if (!r.ok) throw new Error((j && (j.detail || j.message)) || `Erro HTTP ${r.status}`);
    return j;
  }

  function aviso(msg) { const a = $("#aviso"); a.hidden = !msg; a.textContent = msg || ""; }

  function aplicarPreset(p) {
    const hoje = new Date();
    let ini = new Date(hoje), fim = new Date(hoje);
    if (p === "mes") ini = new Date(hoje.getFullYear(), hoje.getMonth(), 1);
    else if (p === "mes_ant") { ini = new Date(hoje.getFullYear(), hoje.getMonth() - 1, 1); fim = new Date(hoje.getFullYear(), hoje.getMonth(), 0); }
    else if (p === "ano") ini = new Date(hoje.getFullYear(), 0, 1);
    else if (p === "custom") return;
    else ini.setDate(hoje.getDate() - (parseInt(p, 10) - 1));
    $("#inicio").value = iso(ini);
    $("#fim").value = iso(fim);
  }

  function iniciais(nome) {
    const p = nome.trim().split(/\s+/).filter(Boolean);
    return ((p[0] || "?")[0] + (p.length > 1 ? p[p.length - 1][0] : "")).toUpperCase();
  }

  function rosto(r, classe) {
    const c = el("div", classe);
    if (r.foto) {
      const img = document.createElement("img");
      img.src = `/api/tecnico/${r.id}/foto?v=${r.foto}`; img.alt = "";
      c.appendChild(img);
    } else c.appendChild(el("span", classe === "rosto" ? "ini" : "", iniciais(r.name)));
    return c;
  }

  const classeNota = (n) => (n === null ? "" : n >= 80 ? "nota-boa" : n >= 50 ? "nota-media" : "nota-ruim");

  function criterio(titulo, valorTxt, nota, dica = "") {
    const c = el("div", "criterio");
    c.title = (dica ? `${dica}. ` : "") +
      (nota === null ? "Sem dados no período: este critério não entra na pontuação." : `Nota ${fmtNum(nota)} de 100`);
    const t = el("div", "topo-crit");
    t.append(el("span", "", titulo), el("strong", "", valorTxt));
    const trilho = el("div", "trilho");
    const s = el("span", classeNota(nota));
    s.style.width = `${nota === null ? 0 : Math.max(2, nota)}%`;
    trilho.appendChild(s);
    c.append(t, trilho);
    return c;
  }

  function horas(h) {
    if (h < 1) return `${Math.round(h * 60)} min`;
    if (h < 48) return `${fmtNum(h)} h`;
    return `${fmtNum(Math.round(h / 24 * 10) / 10)} dias`;
  }

  function linkTecnico(r) {
    const a = el("a", "", r.name);
    a.href = `/tecnico?id=${r.id}`;
    return a;
  }

  function desenharPodio(lista) {
    const podio = $("#podio");
    podio.innerHTML = "";
    if (!lista.length) { podio.appendChild(el("div", "vazio", "Nenhum técnico com atendimentos suficientes no período.")); podio.style.gridTemplateColumns = "1fr"; return; }
    podio.style.gridTemplateColumns = "";
    [0, 1, 2].forEach((i) => {
      const r = lista[i];
      const d = el("article", `degrau p${i + 1}`);
      if (!r) { d.classList.add("vazio-degrau"); podio.appendChild(d); return; }
      d.appendChild(el("span", "lugar", `${r.posicao}º lugar`));
      const moldura = el("div", "rosto-moldura");
      moldura.appendChild(rosto(r, "rosto"));
      if (MEDALHA[r.posicao]) moldura.appendChild(el("span", "medalha", MEDALHA[r.posicao]));
      d.appendChild(moldura);
      const h = el("h3");
      h.appendChild(linkTecnico(r));
      d.appendChild(h);
      const p = el("div", "pontos", fmtNum(r.pontuacao));
      p.appendChild(el("small", "", "pts"));
      d.appendChild(p);
      const sla = r.sla_pct === null ? "sem SLA" : `SLA ${fmtNum(r.sla_pct)}%`;
      d.appendChild(el("div", "resumo", `${r.atendidos} atendidos · ${sla} · ${r.reabertos} reaberto(s)`));
      podio.appendChild(d);
    });
  }

  function desenharLista(dados) {
    const ol = $("#lista");
    ol.innerHTML = "";
    dados.ranking.forEach((r) => {
      const li = el("li", "rk-linha");
      li.appendChild(el("span", "pos", `${r.posicao}º`));
      li.appendChild(rosto(r, "mini"));
      const n = el("div", "nome");
      n.appendChild(linkTecnico(r));
      n.appendChild(el("small", "", `${r.atendidos} atendidos · ${r.solucionados} solucionados`));
      li.appendChild(n);
      const b = el("div", "barra-total");
      const trilho = el("div", "trilho");
      const s = el("span");
      s.style.width = `${Math.max(2, r.pontuacao)}%`;
      trilho.appendChild(s);
      b.append(trilho, el("b", "", fmtNum(r.pontuacao)));
      b.title = "Pontuação de 0 a 100";
      li.appendChild(b);
      const cs = el("div", "criterios");
      cs.append(
        criterio("SLA", r.sla_pct === null ? "–" : `${fmtNum(r.sla_pct)}%`, r.nota_sla,
          r.sla_pct === null ? "" : `${r.no_prazo} de ${r.com_sla} no prazo`),
        criterio("Reabertos", `${r.reabertos} (${fmtNum(r.taxa_reab)}%)`, r.nota_reab, "Solução recusada pelo cliente"),
        criterio("Pendência", horas(r.pend_media_h), r.nota_pend, "Tempo médio em pendência por chamado"),
        criterio("Solução", r.sol_media_h === null ? "–" : horas(r.sol_media_h), r.nota_sol,
          "Tempo médio de solução (calendário do GLPI, sem a pendência)"),
      );
      if (dados.pesos.vol > 0) {
        cs.appendChild(criterio("Carga", `${r.atendidos} atend.`, r.nota_vol,
          "Chamados atendidos (pelos pesos de prioridade), comparados com quem mais atendeu"));
        cs.style.gridTemplateColumns = "repeat(5, 1fr)";
      }
      li.appendChild(cs);
      ol.appendChild(li);
    });
    if (!dados.ranking.length) ol.appendChild(el("li", "vazio", "Ninguém atingiu o mínimo de atendimentos no período."));

    const pe = dados.pesos, lim = dados.limites;
    const partes = [];
    const lim_txt = (v, u) => `${fmtNum(v)}${u} ou mais zera`;
    if (pe.sla > 0) partes.push(`SLA cumprido (peso ${fmtNum(pe.sla)})`);
    if (pe.reab > 0) partes.push(`menos reabertos (peso ${fmtNum(pe.reab)}; ${lim_txt(lim.reab, "%")})`);
    if (pe.pend > 0) partes.push(`menos tempo em pendência (peso ${fmtNum(pe.pend)}; média de ${lim_txt(lim.pend_h, " h")})`);
    if (pe.sol > 0) partes.push(`solução mais rápida (peso ${fmtNum(pe.sol)}; média de ${lim_txt(lim.sol_h, " h")})`);
    if (pe.vol > 0) partes.push(`carga atendida (peso ${fmtNum(pe.vol)}; quem atendeu mais chamados, pelos pesos de prioridade, tira 100)`);
    const ultimo = partes.length > 1 ? ` e ${partes.pop()}` : "";
    $("#regra").textContent = `Pontuação de 0 a 100: ${partes.join(", ")}${ultimo}. ` +
      (dados.ponderado ? "SLA, reaberturas, pendência e solução ponderados pela prioridade do chamado. " : "") +
      `Mínimo de ${dados.minimo} chamados atendidos no período.`;

    desenharFormula(dados);

    const fora = $("#fora");
    fora.hidden = !dados.poucos.length;
    fora.textContent = dados.poucos.length
      ? `Fora do ranking (menos de ${dados.minimo} atendidos): ${dados.poucos.map((p) => `${p.name} (${p.atendidos})`).join(", ")}.`
      : "";
  }

  // ------------------------------------------------------------ formula, com os valores atuais
  function desenharFormula(dados) {
    const corpo = $("#formula-corpo");
    corpo.innerHTML = "";
    const pe = dados.pesos, lim = dados.limites;
    const crit = [
      ["sla", "SLA cumprido", "% dos chamados solucionados (com prazo) que ficaram dentro do prazo",
        "nota = % no prazo"],
      ["reab", "Menos reabertos", "% dos chamados atendidos com a solução recusada pelo cliente",
        `nota = 100 − taxa(%) × 100 ÷ ${fmtNum(lim.reab)}`],
      ["pend", "Menos tempo em pendência", "média de horas em Pendente por chamado atendido",
        `nota = 100 − média(h) × 100 ÷ ${fmtNum(lim.pend_h)}`],
      ["sol", "Solução mais rápida", "média de horas de solução (calendário do GLPI, sem a pendência)",
        `nota = 100 − média(h) × 100 ÷ ${fmtNum(lim.sol_h)}`],
      ["vol", "Carga atendida", "soma dos pesos de prioridade dos chamados atendidos",
        "nota = carga do técnico × 100 ÷ maior carga da equipe"],
    ];
    const total = crit.reduce((t, c) => t + (pe[c[0]] > 0 ? pe[c[0]] : 0), 0);

    corpo.appendChild(el("p", "", "Cada critério vira uma nota de 0 a 100 (nunca abaixo de 0). A pontuação é a média " +
      "dessas notas, ponderada pelos pesos das Configurações:"));
    corpo.appendChild(el("pre", "formula-eq", "Pontuação = (nota SLA × peso SLA + nota reabertura × peso reabertura + … ) ÷ soma dos pesos"));

    const tab = el("table", "formula-tab");
    const cab = el("tr");
    ["Critério", "Peso", "Vale", "O que mede", "Nota"].forEach((t) => cab.appendChild(el("th", "", t)));
    tab.appendChild(cab);
    crit.forEach(([k, nome, mede, nota]) => {
      const tr = el("tr", pe[k] > 0 ? "" : "desligado");
      tr.append(el("td", "", nome), el("td", "num", fmtNum(pe[k])),
        el("td", "num", pe[k] > 0 && total ? `${fmtNum(Math.round(pe[k] * 1000 / total) / 10)}%` : "fora"),
        el("td", "", mede), el("td", "cod", nota));
      tab.appendChild(tr);
    });
    const caixa = el("div", "formula-tab-caixa"); caixa.appendChild(tab);
    corpo.appendChild(caixa);

    const prios = Object.entries(dados.peso_prioridade || {}).map(([n, v]) => `${n} = ${fmtNum(v)}`).join(" · ");
    const notas = [
      `Peso de cada chamado pela prioridade (usado na carga${dados.ponderado ? " e nas demais notas" : ""}): ${prios}.`,
      dados.ponderado
        ? "Ponderado pela prioridade: no SLA, nas reaberturas, na pendência e na solução, um chamado de prioridade alta conta mais que um de prioridade baixa."
        : "Sem ponderação: no SLA, nas reaberturas, na pendência e na solução, todo chamado conta igual.",
      "Critério sem dados para o técnico no período (ex.: nenhum chamado com SLA) fica de fora e os outros pesos se redistribuem.",
      `Atendidos = solucionados ou reabertos no período. Mínimo de ${dados.minimo} para entrar. ` +
      "Empate: maior SLA, menos reabertos, menos pendência, solução mais rápida, maior carga.",
    ];
    const ul = el("ul");
    notas.forEach((t) => ul.appendChild(el("li", "", t)));
    corpo.appendChild(ul);

    const r = dados.ranking[0];
    if (r) {
      const valores = { sla: r.nota_sla, reab: r.nota_reab, pend: r.nota_pend, sol: r.nota_sol, vol: r.nota_vol };
      const usados = crit.filter(([k]) => pe[k] > 0 && valores[k] !== null && valores[k] !== undefined);
      const soma = usados.reduce((t, [k]) => t + pe[k], 0);
      const linhas = usados.map(([k, nome]) =>
        `${nome.padEnd(26, " ")} nota ${String(fmtNum(valores[k])).padStart(5, " ")} × peso ${String(fmtNum(pe[k])).padStart(3, " ")} = ${fmtNum(Math.round(valores[k] * pe[k] * 10) / 10)}`);
      const total_pts = usados.reduce((t, [k]) => t + valores[k] * pe[k], 0);
      linhas.push("".padEnd(60, "─"));
      linhas.push(`Soma ${fmtNum(Math.round(total_pts * 10) / 10)} ÷ soma dos pesos ${fmtNum(soma)} = ${fmtNum(Math.round(total_pts / soma * 10) / 10)} pontos`);
      corpo.appendChild(el("p", "", `Exemplo com o 1º colocado (${r.name}):`));
      corpo.appendChild(el("pre", "formula-eq", linhas.join("\n")));
      corpo.appendChild(el("p", "sutil-ex", "As notas aparecem arredondadas; a conta exata pode diferir em 0,1."));
    }
  }

  async function carregar() {
    clearTimeout(timer);
    const ini = $("#inicio").value, fim = $("#fim").value;
    if (!ini || !fim || ini > fim) { aviso("Confira o período: a data inicial precisa ser anterior à final."); return; }
    try {
      const d = await api(`/api/ranking?${new URLSearchParams({ start: ini, end: fim })}`);
      $("#atualizado").textContent = d.loaded_at ? `Dados do GLPI de ${d.loaded_at}` : "";
      aviso(d.warning || "");
      desenharPodio(d.ranking);
      desenharLista(d);
    } catch (e) {
      aviso(`Não foi possível carregar o ranking: ${e.message}`);
    } finally {
      timer = setTimeout(() => { const p = $("#periodo").value; if (p !== "custom") aplicarPreset(p); carregar(); }, ATUALIZAR_MS);
    }
  }

  function iniciar() {
    const preset = lerLocal("rk.periodo", "30");
    $("#periodo").value = preset;
    if (preset === "custom") {
      const [i, f] = lerLocal("rk.datas", ["", ""]);
      $("#inicio").value = i; $("#fim").value = f;
      if (!i || !f) { $("#periodo").value = "30"; aplicarPreset("30"); }
    } else aplicarPreset(preset);

    $("#periodo").addEventListener("change", (e) => {
      salvarLocal("rk.periodo", e.target.value);
      aplicarPreset(e.target.value);
      if (e.target.value !== "custom") carregar();
    });
    ["#inicio", "#fim"].forEach((s) => $(s).addEventListener("change", () => {
      $("#periodo").value = "custom";
      salvarLocal("rk.periodo", "custom");
      salvarLocal("rk.datas", [$("#inicio").value, $("#fim").value]);
      carregar();
    }));
    const telaCheia = () => {
      if (document.fullscreenElement) document.exitFullscreen();
      else if (document.documentElement.requestFullscreen) document.documentElement.requestFullscreen();
    };
    $("#btn-tela").addEventListener("click", telaCheia);
    document.addEventListener("fullscreenchange", () => {
      const ativo = !!document.fullscreenElement;
      document.body.classList.toggle("tela-cheia", ativo);
      $("#btn-tela").textContent = ativo ? "Sair da tela cheia" : "Tela cheia";
    });
    document.addEventListener("keydown", (e) => {
      if (["INPUT", "SELECT", "TEXTAREA"].includes(document.activeElement.tagName)) return;
      if (e.key === "f" || e.key === "F") telaCheia();
    });
    carregar();
  }

  iniciar();
})();
