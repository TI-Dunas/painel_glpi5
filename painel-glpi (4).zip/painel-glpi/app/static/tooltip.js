/* Balao (tooltip) em HTML para graficos com explicacao longa (ex.: motivos dos chamados "Sem SLA").
   O balao padrao do Chart.js e desenhado dentro do grafico e fica cortado; este flutua sobre a pagina. */
(function () {
  "use strict";
  let caixa = null;

  function obterCaixa() {
    if (caixa) return caixa;
    caixa = document.createElement("div");
    caixa.className = "tooltip-externo";
    caixa.setAttribute("role", "tooltip");
    caixa.hidden = true;
    document.body.appendChild(caixa);
    window.addEventListener("scroll", () => { caixa.hidden = true; }, { passive: true });
    return caixa;
  }

  window.tooltipExterno = function ({ chart, tooltip }) {
    const c = obterCaixa();
    if (!tooltip || tooltip.opacity === 0) { c.hidden = true; return; }
    c.innerHTML = "";
    (tooltip.title || []).forEach((t) => {
      const h = document.createElement("div"); h.className = "tt-titulo"; h.textContent = t; c.appendChild(h);
    });
    (tooltip.body || []).forEach((b, i) => {
      b.lines.forEach((l) => {
        const linha = document.createElement("div"); linha.className = "tt-valor";
        const cor = tooltip.labelColors && tooltip.labelColors[i];
        if (cor) {
          const q = document.createElement("span"); q.className = "tt-cor";
          q.style.background = cor.backgroundColor; linha.appendChild(q);
        }
        linha.appendChild(document.createTextNode(l.trim()));
        c.appendChild(linha);
      });
    });
    const extra = tooltip.afterBody || [];
    if (extra.length) {
      const bloco = document.createElement("div"); bloco.className = "tt-extra";
      extra.forEach((l) => {
        const linha = document.createElement("div");
        const recuo = /^\s+/.test(l);
        linha.className = recuo ? (/^\s+\(/.test(l) ? "tt-nota" : "tt-item") : (l.startsWith("•") ? "tt-motivo" : "tt-cab");
        linha.textContent = recuo ? l.trim().replace(/^\((.*)\)$/, "$1") : l.replace(/^•\s*/, "");
        bloco.appendChild(linha);
      });
      c.appendChild(bloco);
    }
    c.hidden = false;
    const r = chart.canvas.getBoundingClientRect();
    const larg = c.offsetWidth, alt = c.offsetHeight, margem = 8;
    let x = r.left + tooltip.caretX + 14;
    let y = r.top + tooltip.caretY - alt / 2;
    if (x + larg > window.innerWidth - margem) x = r.left + tooltip.caretX - larg - 14;
    x = Math.max(margem, x);
    y = Math.min(Math.max(margem, y), window.innerHeight - alt - margem);
    c.style.left = `${x}px`;
    c.style.top = `${y}px`;
  };
})();
