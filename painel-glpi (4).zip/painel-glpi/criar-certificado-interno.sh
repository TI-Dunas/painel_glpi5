#!/bin/sh
# Emite UM certificado curinga (*.grupovia.lan) assinado por uma CA interna, para usar em
# TODAS as aplicacoes do servidor (GLPI no Apache, este painel, o portal e outros conteineres Docker),
# qualquer que seja a porta. O certificado vale pelo NOME, nao pela porta.
#
#     sudo ./criar-certificado-interno.sh
#
# Variaveis (opcionais):
#   DOMINIO=grupovia.lan        gera *.grupovia.lan e grupovia.lan
#   IPS="10.1.100.128"          IPs extras no certificado (separados por espaco)
#   NOMES=""                    nomes extras (ex.: "helpdesk.outrodominio.lan")
#   DIAS=825                    validade do certificado (a CA vale 10 anos)
#   PASTA_CA=/etc/pki/grupovia-ca
#   CERT_SAIDA=/etc/pki/tls/certs/grupovia-curinga.crt
#   CHAVE_SAIDA=/etc/pki/tls/private/grupovia-curinga.key
#   SEM_PAINEL=1                nao instala no painel (so gera os arquivos)
#   RENOVAR=1                   emite um certificado novo mesmo que o atual ainda sirva
#
# Se o certificado curinga ja existe (ex.: criado pelo portal de consulta), ainda vale por mais de
# 30 dias e cobre os nomes/IPs, ele e REAPROVEITADO: GLPI, portal e painel ficam com o mesmo.
# Renovacoes (RENOVAR=1 ou certificado perto de vencer) usam a MESMA CA: as maquinas que ja
# confiam nela continuam sem aviso (nao e preciso redistribuir nada).
set -e
cd "$(dirname "$0")"

DOMINIO="${DOMINIO:-grupovia.lan}"
IPS="${IPS:-10.1.100.128}"
NOMES="${NOMES:-}"
DIAS="${DIAS:-825}"
PASTA_CA="${PASTA_CA:-/etc/pki/grupovia-ca}"
CERT_SAIDA="${CERT_SAIDA:-/etc/pki/tls/certs/grupovia-curinga.crt}"
CHAVE_SAIDA="${CHAVE_SAIDA:-/etc/pki/tls/private/grupovia-curinga.key}"
CA_CRT="$PASTA_CA/ca.crt"
CA_KEY="$PASTA_CA/ca.key"

falha() { echo "ERRO: $1" >&2; exit 1; }
command -v openssl >/dev/null || falha "openssl não está instalado"
[ "$(id -u)" = "0" ] || falha "rode como root (sudo)"

umask 077
mkdir -p "$PASTA_CA" "$(dirname "$CERT_SAIDA")" "$(dirname "$CHAVE_SAIDA")"
chmod 700 "$PASTA_CA"

# 1. CA interna: reaproveita a existente; se o painel ja tinha criado uma (e ela ja foi
#    distribuida), adota essa para nao precisar redistribuir.
if [ -s "$CA_CRT" ] && [ -s "$CA_KEY" ]; then
    echo "Usando a CA existente em $PASTA_CA"
elif [ -s data/certs/ca.crt ] && [ -s data/certs/ca.key ]; then
    echo "Adotando a CA criada pelo painel (data/certs) e movendo a chave para $PASTA_CA"
    cp data/certs/ca.crt "$CA_CRT"
    cp data/certs/ca.key "$CA_KEY"
    rm -f data/certs/ca.key
else
    echo "Criando CA interna em $PASTA_CA"
    openssl req -x509 -newkey rsa:4096 -sha256 -days 3650 -nodes \
        -keyout "$CA_KEY" -out "$CA_CRT" \
        -subj "/O=Grupo Via/CN=Grupo Via - CA interna" \
        -addext "basicConstraints=critical,CA:TRUE,pathlen:0" \
        -addext "keyUsage=critical,keyCertSign,cRLSign" \
        -addext "subjectKeyIdentifier=hash" >/dev/null 2>&1 \
        || falha "não foi possível criar a CA (OpenSSL 1.1.1 ou mais novo é necessário)"
fi
chmod 600 "$CA_KEY"
chmod 644 "$CA_CRT"
# a chave da CA fica so em $PASTA_CA (uma copia antiga em data/certs nao combinaria com a CA em uso)
rm -f data/certs/ca.key

# 2. Lista de nomes (SAN)
SAN="DNS:*.$DOMINIO,DNS:$DOMINIO"
for n in $NOMES; do SAN="$SAN,DNS:$n"; done
for ip in $IPS; do SAN="$SAN,IP:$ip"; done

# 3. Reaproveita o curinga existente (mesmo do portal/GLPI) se ele ainda servir
serve() {
    [ -s "$CERT_SAIDA" ] && [ -s "$CHAVE_SAIDA" ] || return 1
    openssl verify -CAfile "$CA_CRT" "$CERT_SAIDA" >/dev/null 2>&1 || return 1
    openssl x509 -in "$CERT_SAIDA" -noout -checkend $((30*86400)) >/dev/null 2>&1 || return 1
    openssl x509 -in "$CERT_SAIDA" -noout -checkhost "teste.$DOMINIO" 2>/dev/null | grep -q "does match" || return 1
    openssl x509 -in "$CERT_SAIDA" -noout -checkhost "$DOMINIO" 2>/dev/null | grep -q "does match" || return 1
    for n in $NOMES; do
        openssl x509 -in "$CERT_SAIDA" -noout -checkhost "$n" 2>/dev/null | grep -q "does match" || return 1
    done
    for ip in $IPS; do
        openssl x509 -in "$CERT_SAIDA" -noout -checkip "$ip" 2>/dev/null | grep -q "does match" || return 1
    done
    A=$(openssl x509 -in "$CERT_SAIDA" -noout -pubkey | openssl sha256)
    B=$(openssl pkey -in "$CHAVE_SAIDA" -pubout 2>/dev/null | openssl sha256)
    [ "$A" = "$B" ]
}

TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
if [ -z "$RENOVAR" ] && serve; then
    echo "Reaproveitando o certificado existente $CERT_SAIDA (ainda válido e com os nomes/IPs)."
    echo "Para emitir um novo: RENOVAR=1 $0"
    NOVO=""
else
NOVO=1
cat > "$TMP/ext.cnf" <<FIM
basicConstraints=critical,CA:FALSE
keyUsage=critical,digitalSignature,keyEncipherment
extendedKeyUsage=serverAuth
subjectAltName=$SAN
subjectKeyIdentifier=hash
authorityKeyIdentifier=keyid
FIM
openssl req -newkey rsa:2048 -nodes -keyout "$TMP/chave.key" -out "$TMP/req.csr" \
    -subj "/O=Grupo Via/CN=*.$DOMINIO" >/dev/null 2>&1
openssl x509 -req -in "$TMP/req.csr" -CA "$CA_CRT" -CAkey "$CA_KEY" -CAcreateserial \
    -CAserial "$PASTA_CA/ca.srl" -out "$TMP/cert.crt" -days "$DIAS" -sha256 \
    -extfile "$TMP/ext.cnf" >/dev/null 2>&1 || falha "não foi possível emitir o certificado"
openssl verify -CAfile "$CA_CRT" "$TMP/cert.crt" >/dev/null || falha "o certificado emitido não confere com a CA"

install -m 644 "$TMP/cert.crt" "$CERT_SAIDA"
install -m 600 "$TMP/chave.key" "$CHAVE_SAIDA"
cat "$CERT_SAIDA" "$CA_CRT" > "${CERT_SAIDA%.crt}-cadeia.crt"     # certificado + CA (p/ quem pede fullchain)
chmod 644 "${CERT_SAIDA%.crt}-cadeia.crt"
fi

# 4. O proprio servidor passa a confiar na CA (curl, scripts, outros conteineres via bind)
if [ -d /etc/pki/ca-trust/source/anchors ]; then
    cp "$CA_CRT" /etc/pki/ca-trust/source/anchors/grupovia-ca.crt && update-ca-trust extract
elif [ -d /usr/local/share/ca-certificates ]; then
    cp "$CA_CRT" /usr/local/share/ca-certificates/grupovia-ca.crt && update-ca-certificates >/dev/null 2>&1
fi
command -v restorecon >/dev/null && restorecon -F "$CERT_SAIDA" "${CERT_SAIDA%.crt}-cadeia.crt" "$CHAVE_SAIDA" 2>/dev/null || true

echo
echo "Certificado emitido:"
openssl x509 -in "$CERT_SAIDA" -noout -subject -enddate | sed 's/^/  /'
echo "  nomes: $SAN"
echo "  certificado: $CERT_SAIDA"
echo "  com a CA:    ${CERT_SAIDA%.crt}-cadeia.crt"
echo "  chave:       $CHAVE_SAIDA"
echo "  CA (GPO):    $CA_CRT"

# 5. Instala no painel (copia; nao monta, para nao mexer no SELinux do Apache)
if [ -z "$SEM_PAINEL" ]; then
    mkdir -p data/certs
    install -m 644 "$CA_CRT" data/certs/ca.crt
    CERT="$CERT_SAIDA" CHAVE="$CHAVE_SAIDA" NOME="helpdesk.$DOMINIO" ./usar-certificado-glpi.sh
fi

cat <<FIM

Próximos passos:
  1. Distribua $CA_CRT por GPO em "Autoridades de Certificação Raiz Confiáveis"
     (só na primeira vez; renovações usam a mesma CA).
  2. GLPI (Apache), no glpi.conf / ssl.conf (se ainda não estiver):
        SSLCertificateFile    $CERT_SAIDA
        SSLCertificateKeyFile $CHAVE_SAIDA
     e depois: systemctl reload httpd${NOVO:+   (certificado NOVO: recarregue o Apache e rode
     ./usar-certificado-glpi.sh também na pasta do portal de consulta)}
  3. Outros conteineres: use $CERT_SAIDA e $CHAVE_SAIDA (copie para a pasta de dados
     de cada um, como o painel faz) e crie no DNS um nome NOME.$DOMINIO para cada aplicação.
FIM
